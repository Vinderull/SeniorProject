*PADS-LIBRARY-SCH-DECALS-V9*

P6SMB12CAT3G -200  0     100 10 100 10 4 5 0 2 8
TIMESTAMP 2017.10.19.15.20.25
"Default Font"
"Default Font"
600   350   0 0 100 10 "Default Font"
REF-DES
600   250   0 0 100 10 "Default Font"
PART-TYPE
600   -200  0 0 100 10 "Default Font"
*
600   -300  0 0 100 10 "Default Font"
*
CLOSED 4 10 0 -1
400   0    
600   100  
600   -100 
400   0    
CLOSED 4 10 0 -1
400   0    
200   100  
200   -100 
400   0    
OPEN   2 10 0 -1
400   -80  
440   -100 
OPEN   2 10 0 -1
360   100  
400   80   
OPEN   2 10 0 -1
400   -80  
400   80   
T0     0     0 0 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T800   0     0 2 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0

PIN 34000 34000 0 0 0 0 4 1 0 0 0
TIMESTAMP 2018.10.21.23.54.37
"Default Font"
"Default Font"
140 20 0 1 100 10
REF-DES
230 0 0 8 100 10
PART-TYPE
-520 0 0 1 100 10
*
-80 0 0 1 100 10
*
OPEN 2 10 0 -1
0 0
200 0

PINSHORT 34000 34000 0 0 0 0 4 1 0 0 0
TIMESTAMP 2018.10.21.23.54.37
"Default Font"
"Default Font"
60 10 0 1 100 10
REF-DES
140 10 0 8 100 10
PART-TYPE
-530 10 0 1 100 10
*
-70 10 0 1 100 10
*
OPEN 2 10 0 -1
0 0
100 0

*END*


